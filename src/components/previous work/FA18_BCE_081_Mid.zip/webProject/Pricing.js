const Pricing = () => {
    return <h1>Pricing</h1>;
  };
  
  export default Pricing;