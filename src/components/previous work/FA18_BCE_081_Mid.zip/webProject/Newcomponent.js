import HomeCarousel from "./HomeCarousel";


const Newcomponent = () => {
    return(
        <div>
            <HomeCarousel/>
        </div>
    )
  };
  
  export default Newcomponent;