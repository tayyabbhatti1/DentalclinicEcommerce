import Signup from "./Signup";

const Contactus = () => {
    return(
        <div>
            <Signup/>
        </div>
    )
  };
  
  export default Contactus;